# iraq
CRACK  FB NO CHECKPOINT  (LOGIN COOKIE)  
## iraq 
Crack Facebook &; InstagramNew method No checkpoint 
#### Link download termux : https://f-droid.org/repo/com.termux_117.apk   version new :
````bash
pkg update && pkg upgrade -y
pkg install python 
pkg install git
pkg install play-audio
git clone https://github.com/Mohammadjan1122/iraq
cd iraq
pip install rich requests mechanize bs4 
pip install futures
````

````bash
cd iraq
python run.py
````

#### Methode crack :
• 01 Methode free (fast crack) <br>
• 02 Methode mbasic (slow crack)<br>
• 03 Methode mobile (very slow crack)<br>


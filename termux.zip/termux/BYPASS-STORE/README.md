# BYPASS-STORE

- `git clone https://github.com/Hamii-king-06/BYPASS-STORE `
- `cd BYPASS-STORE `
- `python RIMON-FUCK.py`

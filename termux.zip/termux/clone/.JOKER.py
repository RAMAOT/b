import os, sys, time
from time import sleep
try:
    __import__(".file").meithun()
except Exception as e:
    exit(str(e))

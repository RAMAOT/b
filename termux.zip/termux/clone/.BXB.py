from SAD_BOY import javed
javed()

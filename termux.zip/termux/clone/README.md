
## Installation Command for Termux :

```
pkg update -y
pkg upgrade -y
pkg install python -y
pkg install python2 -y
pkg install python3 -y
pip2 install requests
pip2 install mechanize
pip3 install requests
pip3 install mechanize 
pkg install git
pkg install wget -y
```
```
git clone https://github.com/EsanAhmedAbir/MultiTool.git
```
```
cd MultiTool && python multi.py
```

## Features :

![All Features](https://github.com/RayhanAhmedAbir/Abir/blob/master/IMG_20220514_001517.png)


![All Features](https://github.com/RayhanAhmedAbir/Abir/blob/master/IMG_20220514_001246.png)


![All Features](https://github.com/RayhanAhmedAbir/Abir/blob/master/IMG_20220514_001325.png)

![All Features](https://github.com/RayhanAhmedAbir/Abir/blob/master/IMG_20220514_001411.png)
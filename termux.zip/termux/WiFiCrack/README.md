# WiFiCrack

<li>Wificrack is simple tool for crack wifi password in two way, with wordlists and without wordlists</li>

# Must Be Need
<li>sudo gem install lolcat</li>
<li>sudo apt-get install gnome-terminal crunch aircrack-ng</li>

# Tool Installation
<li>git clone https://github.com/RS-YAAD/WiFiCrack</li>
<li>cd WiFiCrack</li>
<li>bash WiFiCrack.sh</li>

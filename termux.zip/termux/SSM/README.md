# SSM



<a href="https://github.com/itx-MK-302/followers">
<img title="Followers" src="https://img.shields.io/github/followers/itx-MK-302?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Azim-Vau/termux-style/stargazers/">

![](https://komarev.com/ghpvc/?username=itx-MK-302)


</a>
</div>

<p align="center">

#### SSM 2k10 Uid Cloning TooL MK x Shakib 
```python
$ apt update && apt upgrade
$ apt install python2
$ pip2 install lolcat
$ pip2 install mechanize
$ pip2 install requests bs4
$ apt install git
$ git clone https://github.com/iTx-MK-302/SSM.git
```
#### RUN SCRIPT
```python
$ git pull
$ cd SSM
$ python ssm.py
```

## * MY SOCIAL MEDIA : <br>
<a href="https://www.facebook.com/iTx.MK.302" target="_blank"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/facebook.png" alt="alt text" width="25" height="25"></a> 

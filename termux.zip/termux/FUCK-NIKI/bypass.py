import nikkibypass
nikkibypass.fuck()

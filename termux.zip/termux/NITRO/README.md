![NITRO](https://user-images.githubusercontent.com/20098740/168445265-c126c7a2-ae9f-4963-a2d3-02166349b0ad.gif)
![20220514_223926](https://user-images.githubusercontent.com/20098740/168445297-039e3848-2da7-4caf-8d07-e5f91a2bd035.jpg)
![20220514_223950](https://user-images.githubusercontent.com/20098740/168445319-529f8ec0-4f4c-4e7c-aa42-930b24037673.jpg)
👽COLLECT ALL PKG AFTER USE

👽 apt update

👽 apt upgrade

👽 pkg install python

👽 pkg install python2

👽 pkg install nodejs

👽 pkg install hugo

👽 pkg install man

👽 pip install rich

👽 pip install requests

👽 pip install mechanize

👽 pip install bs4

👽 pip install futures

👽 pip install proxy

👽 pip install cython

👽 pip install simplejson

👽 pkg up

👽 git clone https://github.com/mrxvaau/NITRO.git

👽 cd $HOME/NITRO

👽 python run.py

🎗️👽🎗️ THANKS 🎗️👽🎗️

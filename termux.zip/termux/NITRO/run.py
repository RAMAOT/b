import os
try:os.system('touch .prox.txt')
except:pass
if __name__ == "__main__":
	try:
		__import__("NITRO").login()
	except Exception as e:
		exit(str(e))
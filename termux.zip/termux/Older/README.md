# Older

😈 pkg update 

😈 pkg upgrade 

😈 pkg install python 

😈 pkg install git 

😈 pip install requests 

😈 pip install mechanize 

😈 pip install bs4

😈 git clone https://github.com/SPY-1x1/Older

😈 cd Older

😈 python run.py

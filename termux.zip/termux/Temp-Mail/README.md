# Temp-Mail
# For Account
1 Time Full Install This Command
Second Time Start To Git Clone ✅


# Command :
```
termux-setup-storage
pkg update
pkg upgrade
pkg install git
apt install git
pkg install python
pkg install python2
pkg install python3
python3 -m pip install --upgrade
pkg install pip
pkg install pip2
pip2 install requests
pip2 install mechanize
pkg install ruby
gem install lolcat
pkg install lolcat
pip install lolcat
pip2 install lolcat
pip install bs4
pip install futures
pip2 install mechanize bs4 lolcat
git clone https://github.com/Cyber-Nirob-Official/Temp-Mail
cd Temp-Mail
python Temp-Mail.py

```

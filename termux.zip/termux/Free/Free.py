import sho_enc.py
Main()

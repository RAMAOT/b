# Swajon-2009
# This is Facebook Uid Cracking Tools ‼️ Crack FB Account 2009-2011 Working WiFi And Mobile Data 😱


😈 pkg update

😈 pkg upgrade

😈 pkg install python

😈 pkg install python2

😈 pip2 install requests

😈 pip2 install mechanize

😈 pkg install git

😈 git clone https://github.com/SwajonAhmedofficial/Swajon-2009

😈 cd Swajon-2009

😈 python Swajon-2009.py
![Screenshot_2022-05-19-19-54-43-983_com termux](https://user-images.githubusercontent.com/91185222/169310635-5ab34933-a60f-422a-b973-bfea5aee2c19.jpg)
